/* ============================================================
   MISI TAPIN - Tangga Pintar Pembagian
   Logika permainan: layar, lima level, bintang, skor, suara
   ============================================================ */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var stage = $('#stage');
  var KURANG = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (KURANG) document.body.classList.add('kurang');

  /* ---------- skala panggung 1600 x 900 ---------- */
  var skala = 1;
  function pas() {
    var w = window.innerWidth, h = window.innerHeight;
    skala = Math.min(w / 1600, h / 900);
    var x = (w - 1600 * skala) / 2, y = (h - 900 * skala) / 2;
    stage.style.transform = 'translate(' + x + 'px,' + y + 'px) scale(' + skala + ')';
  }
  window.addEventListener('resize', pas);
  pas();

  /* ---------- data level ---------- */
  var WARNA = [
    { k1: '#b673f5', k2: '#7a2fd6' }, { k1: '#5bb4ff', k2: '#1769d1' }, { k1: '#9be04a', k2: '#3f9a0b' },
    { k1: '#ffd34d', k2: '#e08a00' }, { k1: '#ff9a4d', k2: '#e0500a' }
  ];
  // posisi anak tangga pada tangga.webp (1600 x 900)
  var BAND = [
    { x: 300, y: 680, w: 996, h: 166 }, { x: 366, y: 543, w: 864, h: 136 }, { x: 420, y: 422, w: 760, h: 119 },
    { x: 467, y: 312, w: 666, h: 108 }, { x: 507, y: 205, w: 588, h: 105 }
  ];
  var TENGAH_Y = [762, 610, 481, 366, 257];

  var LEVEL = [
    {
      nama: 'Pembagi Pemula', tipe: 'pensil',
      soal: 'Ibu guru memiliki 8 pensil yang akan dibagikan sama banyak kepada 2 kelompok. Tentukan banyak pensil yang diterima setiap kelompok.',
      langkah: [{ label: 'Setiap kelompok menerima ...', jawab: 4, satuan: 'pensil' }],
      petunjuk: 'Bagikan satu per satu secara bergiliran sampai semua pensil habis.',
      bahas: '<b>8 : 2 = 4.</b> Jadi setiap kelompok menerima 4 pensil.'
    },
    {
      nama: 'Sahabat Pembagian', tipe: 'buku',
      soal: 'Ada 20 buku cerita. Setiap rak diisi 5 buku. Tentukan banyak rak yang diperlukan.',
      langkah: [{ label: 'Banyak rak yang diperlukan ...', jawab: 4, satuan: 'rak' }],
      petunjuk: 'Ambil lima buku setiap kali, lalu hitung berapa kali kamu mengambil.',
      bahas: '<b>20 − 5 − 5 − 5 − 5 = 0.</b> Pengurangan dilakukan 4 kali, jadi diperlukan 4 rak.'
    },
    {
      nama: 'Jago Membagi', tipe: 'krayon',
      soal: 'Sebanyak 42 krayon dimasukkan sama banyak ke dalam 6 kotak. Tentukan banyak krayon di setiap kotak.',
      langkah: [{ label: 'Banyak krayon di setiap kotak ...', jawab: 7, satuan: 'krayon' }],
      petunjuk: 'Cari bilangan yang jika dikali 6 hasilnya 42.',
      bahas: '<b>6 × 7 = 42,</b> maka 42 : 6 = 7. Setiap kotak berisi 7 krayon.'
    },
    {
      nama: 'Penakluk Pembagian', tipe: 'kertas',
      soal: 'Ibu guru memiliki 72 lembar kertas warna untuk 3 kelompok prakarya. Tentukan banyak kertas yang diterima setiap kelompok dengan cara bersusun.',
      langkah: [
        { label: 'Bagi puluhannya: 7 : 3 = ...', jawab: 2, satuan: 'puluhan', baris: '<mark>7</mark> puluhan : 3 = {A} puluhan' },
        { label: 'Sisa puluhan: 7 − (3 × 2) = ...', jawab: 1, satuan: 'puluhan', baris: '<mark>7</mark> − (3 × 2) = {A} puluhan sisa' },
        { label: 'Turunkan satuannya, 12 : 3 = ...', jawab: 4, satuan: '', baris: '1 puluhan + 2 satuan = <mark>12</mark>, lalu 12 : 3 = {A}' },
        { label: 'Jawaban akhir: 72 : 3 = ...', jawab: 24, satuan: 'lembar', baris: 'Jadi <mark>72 : 3</mark> = {A}' }
      ],
      petunjuk: 'Bagi puluhannya dulu, lalu turunkan angka satuannya.',
      bahas: '<b>7 : 3 = 2 sisa 1.</b> Sisa 1 puluhan digabung 2 satuan menjadi 12. 12 : 3 = 4. Hasilnya 24. Periksa: 24 × 3 = 72.'
    },
    {
      nama: 'Pahlawan Pembagian', tipe: 'stiker',
      soal: 'Sekolah menyediakan 62 stiker. Sebanyak 8 stiker dipakai untuk papan kelas. Sisanya dibagikan sama banyak kepada 6 kelompok. Tentukan banyak stiker yang diterima setiap kelompok, lalu periksa jawabanmu dengan perkalian.',
      langkah: [
        { label: 'Stiker yang tersisa: 62 − 8 = ...', jawab: 54, satuan: 'stiker', baris: '<mark>62 − 8</mark> = {A} stiker' },
        { label: 'Hasil bagi: 54 : 6 = ...', jawab: 9, satuan: 'stiker', baris: '<mark>54 : 6</mark> = {A} stiker tiap kelompok' },
        { label: 'Periksa dengan perkalian: 9 × 6 = ...', jawab: 54, satuan: '', baris: 'Periksa: <mark>9 × 6</mark> = {A}' }
      ],
      petunjuk: 'Kurangi dulu stiker yang terpakai, baru bagi sisanya.',
      bahas: '<b>62 − 8 = 54.</b> 54 : 6 = 9. Periksa: 9 × 6 = 54, lalu 54 + 8 = 62. Jadi setiap kelompok menerima 9 stiker.'
    }
  ];


  /* ---------- Alur PBL di tiap misi ----------
     Orientasi masalah (guru) lalu Pahami, Rencanakan, Selesaikan, Periksa. Refleksi ada di akhir. */
  LEVEL[0].langkah.push({ label: 'Periksa dengan perkalian: 4 × 2 = ...', jawab: 8, satuan: 'pensil', tahap: 'periksa' });
  LEVEL[1].langkah.push({ label: 'Periksa dengan perkalian: 4 × 5 = ...', jawab: 20, satuan: 'buku', tahap: 'periksa' });
  LEVEL[2].langkah.push({ label: 'Periksa dengan perkalian: 7 × 6 = ...', jawab: 42, satuan: 'krayon', tahap: 'periksa' });
  LEVEL[3].langkah.push({ label: 'Periksa dengan perkalian: 24 × 3 = ...', jawab: 72, satuan: 'lembar', baris: 'Periksa: <mark>24 × 3</mark> = {A}', tahap: 'periksa' });
  LEVEL[4].langkah[2].tahap = 'periksa';
  var PBL = [
    { orientasi: 'Anak-anak, ibu guru punya masalah. Delapan pensil harus dibagi adil untuk dua kelompok. Yuk kita selidiki bersama!',
      diketahui: '8 pensil, 2 kelompok', ditanya: 'banyak pensil tiap kelompok',
      pahami: { tanya: 'Apa yang ditanyakan pada soal?', opsi: ['Banyak pensil yang diterima setiap kelompok', 'Banyak kelompok seluruhnya', 'Jumlah semua pensil'] },
      rencana: { tanya: 'Cara apa yang cocok untuk masalah ini?', opsi: ['Membagikan satu per satu sampai habis', 'Menjumlahkan 8 dan 2', 'Mengalikan 8 dengan 2'] } },
    { orientasi: 'Buku cerita di kelas harus dirapikan ke rak. Ayo kita cari tahu rak yang diperlukan!',
      diketahui: '20 buku, tiap rak 5 buku', ditanya: 'banyak rak yang diperlukan',
      pahami: { tanya: 'Apa yang ditanyakan pada soal?', opsi: ['Banyak rak yang diperlukan', 'Banyak buku di setiap rak', 'Jumlah semua buku'] },
      rencana: { tanya: 'Cara apa yang cocok untuk masalah ini?', opsi: ['Mengurangi 20 dengan 5 berulang sampai habis', 'Menjumlahkan 20 dan 5', 'Mengalikan 20 dengan 5'] } },
    { orientasi: 'Krayon kelas harus dibagi rata ke beberapa kotak. Mari kita selidiki isi tiap kotak!',
      diketahui: '42 krayon, 6 kotak', ditanya: 'banyak krayon tiap kotak',
      pahami: { tanya: 'Apa yang ditanyakan pada soal?', opsi: ['Banyak krayon di setiap kotak', 'Banyak kotak yang diperlukan', 'Jumlah seluruh krayon'] },
      rencana: { tanya: 'Cara apa yang cocok untuk masalah ini?', opsi: ['Mencari bilangan yang jika dikali 6 hasilnya 42', 'Menjumlahkan 42 dan 6', 'Mengurangi 42 dengan 6 satu kali'] } },
    { orientasi: 'Ibu guru menyiapkan kertas warna untuk prakarya. Mari cari cara membaginya adil ke tiga kelompok.',
      diketahui: '72 lembar, 3 kelompok', ditanya: 'banyak kertas tiap kelompok',
      pahami: { tanya: 'Apa yang ditanyakan pada soal?', opsi: ['Banyak kertas yang diterima setiap kelompok', 'Banyak seluruh kertas warna', 'Banyak kelompok prakarya'] },
      rencana: { tanya: 'Cara apa yang cocok untuk masalah ini?', opsi: ['Membagi puluhan lebih dulu, lalu satuan (bersusun)', 'Menjumlahkan 72 dan 3', 'Mengalikan 72 dengan 3'] } },
    { orientasi: 'Ini misi terakhir! Stikernya sudah terpakai sebagian. Kita cari tahu bagian tiap kelompok.',
      diketahui: '62 stiker, 8 terpakai, 6 kelompok', ditanya: 'banyak stiker tiap kelompok',
      pahami: { tanya: 'Apa yang ditanyakan pada soal?', opsi: ['Banyak stiker yang diterima setiap kelompok', 'Banyak stiker yang dipakai untuk papan', 'Banyak kelompok seluruhnya'] },
      rencana: { tanya: 'Cara apa yang cocok untuk masalah ini?', opsi: ['Kurangi dulu stiker yang terpakai, lalu bagi sisanya', 'Bagi 62 dengan 6 langsung', 'Kalikan 62 dengan 8'] } }
  ];
  PBL.forEach(function (p, i) { LEVEL[i].pbl = p; });
  var REFLEKSI = [
    'Membagikan satu per satu sampai habis',
    'Mengurangi berulang sampai habis',
    'Mencari kebalikan perkalian',
    'Membagi puluhan lalu satuan (bersusun)'
  ];

  /* ---------- penyimpanan (aman bila gagal) ---------- */
  var KUNCI = 'misiTapin_v1';
  function muat() {
    try {
      var s = JSON.parse(localStorage.getItem(KUNCI));
      if (s && s.selesai && s.bintang && s.selesai.length === 5) return s;
    } catch (e) {}
    return { selesai: [false, false, false, false, false], bintang: [0, 0, 0, 0, 0] };
  }
  function simpan() { try { localStorage.setItem(KUNCI, JSON.stringify(progres)); } catch (e) {} }
  var progres = muat();

  /* ---------- suara (Web Audio, tanpa berkas) ---------- */
  var ac = null, bisu = false;
  function nyalakan() {
    if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; } }
    if (ac && ac.state === 'suspended') { try { ac.resume(); } catch (e) {} }
  }
  function nada(f, t0, d, tipe, v) {
    if (!ac || bisu) return;
    try {
      var o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime + t0;
      o.type = tipe || 'sine'; o.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v || 0.14, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + d + 0.05);
    } catch (e) {}
  }
  var suara = {
    klik: function () { nada(660, 0, 0.08, 'triangle', 0.1); },
    benar: function () { [523, 659, 784, 1047].forEach(function (f, i) { nada(f, i * 0.1, 0.28, 'triangle', 0.15); }); },
    salah: function () { nada(300, 0, 0.18, 'sine', 0.12); nada(240, 0.16, 0.28, 'sine', 0.1); },
    langkah: function () { nada(784, 0, 0.12, 'triangle', 0.12); nada(988, 0.09, 0.2, 'triangle', 0.12); },
    bintang: function (i) { nada(700 + i * 120, 0, 0.22, 'triangle', 0.12); },
    pop: function () { nada(880, 0, 0.06, 'square', 0.05); }
  };
  document.addEventListener('pointerdown', nyalakan, { once: false });
  document.addEventListener('keydown', nyalakan);
  $('#btn-suara').addEventListener('click', function () {
    bisu = !bisu; this.classList.toggle('mati', bisu); this.setAttribute('aria-pressed', String(bisu));
    if (!bisu) suara.klik();
  });

  /* ---------- musik latar (dibuat langsung dengan Web Audio, tanpa berkas) ---------- */
  // Lagu asli dalam nada C mayor, 116 bpm, 16 birama: bagian A (riang) dan bagian B (berloncatan)
  var M_BPM = 116, M_AKOR = [[48, [60, 64, 67]], [45, [57, 60, 64]], [41, [57, 60, 65]], [43, [59, 62, 67]]];
  var M_A = [
    [76,79,81,79,76,72,74,76], [81,79,76,79,81,0,76,0], [77,81,77,72,74,77,81,77], [79,77,74,71,74,77,79,0],
    [76,79,81,79,76,72,74,76], [81,84,81,79,76,79,81,0], [77,81,84,81,79,77,74,72], [74,71,74,77,79,0,76,0]
  ];
  var M_B = [
    [79,0,79,76,72,76,79,0], [81,0,81,79,76,79,81,0], [77,0,77,81,84,81,77,0], [79,77,74,0,71,74,79,0],
    [79,0,79,76,72,76,79,84], [81,79,76,81,79,76,72,0], [77,81,84,81,77,74,72,0], [74,77,79,71,72,0,0,0]
  ];
  var MELODI = M_A.concat(M_B);
  var musik = { jalan: false, mati: false, gain: null, timer: null, langkah: 0, tNext: 0, derau: null, faktor: 1 };
  var VOL_MUSIK = 0.5;
  function hz(m) { return 440 * Math.pow(2, (m - 69) / 12); }
  function nadaM(f, t, d, tipe, v, ke) {
    try {
      var o = ac.createOscillator(), g = ac.createGain();
      o.type = tipe; o.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(ke || musik.gain); o.start(t); o.stop(t + d + 0.05);
    } catch (e) {}
  }
  function derauM(t, d, v, hp) {
    try {
      var src = ac.createBufferSource(), g = ac.createGain(), f = ac.createBiquadFilter();
      src.buffer = musik.derau; f.type = 'highpass'; f.frequency.value = hp;
      g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      src.connect(f); f.connect(g); g.connect(musik.gain); src.start(t); src.stop(t + d + 0.02);
    } catch (e) {}
  }
  function kick(t) {
    try {
      var o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(48, t + 0.12);
      g.gain.setValueAtTime(0.38, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      o.connect(g); g.connect(musik.gain); o.start(t); o.stop(t + 0.2);
    } catch (e) {}
  }
  function jadwalMusik() {
    var det = 60 / M_BPM / 2; // satu langkah = seperdelapan
    while (musik.tNext < ac.currentTime + 0.35) {
      var i = musik.langkah % 128, bar = Math.floor(i / 8), k = i % 8, t = musik.tNext;
      var ak = M_AKOR[bar % 4], mel = MELODI[bar][k];
      if (mel) { nadaM(hz(mel), t, det * 1.7, 'triangle', 0.2); nadaM(hz(mel + 12), t, det * 0.9, 'sine', 0.035); }
      // petikan akor
      var ap = [0, 1, 2, 1, 0, 1, 2, 1][k]; nadaM(hz(ak[1][ap]), t, det * 1.3, 'sine', 0.07);
      // bass
      if (k === 0 || k === 4) nadaM(hz(ak[0]), t, det * 3.2, 'triangle', 0.3);
      if (k === 2 || k === 6) nadaM(hz(ak[0] + 7), t, det * 1.1, 'triangle', 0.14);
      // perkusi lembut
      if (k === 0 || k === 4) kick(t);
      if (k === 2 || k === 6) derauM(t, 0.09, 0.12, 1800);
      derauM(t, 0.03, 0.035, 7000);
      musik.tNext += det; musik.langkah++;
    }
  }
  function volMusik(nama) {
    var f = { pembuka: 1, sapa: 0.9, cara: 0.7, refleksi: 0.7, peta: 0.9, soal: 0.4, umpan: 0.55, skor: 1 }[nama];
    musik.faktor = f == null ? 1 : f;
    if (musik.gain && ac) musik.gain.gain.setTargetAtTime(musik.mati ? 0 : VOL_MUSIK * musik.faktor, ac.currentTime, 0.4);
  }
  function mulaiMusik() {
    if (musik.jalan || !ac) return;
    try {
      musik.gain = ac.createGain(); musik.gain.gain.value = 0; musik.gain.connect(ac.destination);
      var n = ac.sampleRate * 0.5, buf = ac.createBuffer(1, n, ac.sampleRate), d = buf.getChannelData(0);
      for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      musik.derau = buf; musik.tNext = ac.currentTime + 0.15; musik.langkah = 0; musik.jalan = true;
      musik.timer = setInterval(jadwalMusik, 60);
      volMusik(layarKini);
    } catch (e) { musik.jalan = false; }
  }
  document.addEventListener('visibilitychange', function () {
    if (!ac) return;
    try { if (document.hidden) ac.suspend(); else ac.resume(); } catch (e) {}
  });
  document.addEventListener('pointerdown', function () { nyalakan(); mulaiMusik(); });
  document.addEventListener('keydown', function () { nyalakan(); mulaiMusik(); });
  $('#btn-musik').addEventListener('click', function () {
    musik.mati = !musik.mati; this.classList.toggle('mati', musik.mati); this.setAttribute('aria-pressed', String(musik.mati));
    nyalakan(); mulaiMusik(); volMusik(layarKini);
  });

  /* ---------- konfeti ---------- */
  var cv = $('#konfeti'), cx = cv.getContext('2d'), partikel = [], animK = 0;
  function konfeti(jumlah) {
    if (KURANG) return;
    var warna = ['#f43f5e', '#fb923c', '#facc15', '#4ade80', '#38bdf8', '#a78bfa'];
    for (var i = 0; i < (jumlah || 140); i++) {
      partikel.push({
        x: 300 + Math.random() * 1000, y: -20 - Math.random() * 300, vx: (Math.random() - 0.5) * 5, vy: 3 + Math.random() * 5,
        r: 7 + Math.random() * 9, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4, c: warna[i % warna.length], bentuk: i % 3
      });
    }
    if (!animK) loopK();
  }
  function loopK() {
    cx.clearRect(0, 0, 1600, 900);
    partikel = partikel.filter(function (p) { return p.y < 940; });
    partikel.forEach(function (p) {
      p.x += p.vx; p.y += p.vy; p.vy += 0.06; p.rot += p.vr;
      cx.save(); cx.translate(p.x, p.y); cx.rotate(p.rot); cx.fillStyle = p.c;
      if (p.bentuk === 0) cx.fillRect(-p.r / 2, -p.r / 3, p.r, p.r * 0.6);
      else if (p.bentuk === 1) { cx.beginPath(); cx.arc(0, 0, p.r / 2, 0, 7); cx.fill(); }
      else { cx.beginPath(); cx.moveTo(0, -p.r / 2); cx.lineTo(p.r / 2, p.r / 2); cx.lineTo(-p.r / 2, p.r / 2); cx.closePath(); cx.fill(); }
      cx.restore();
    });
    if (partikel.length) animK = requestAnimationFrame(loopK); else { animK = 0; cx.clearRect(0, 0, 1600, 900); }
  }

  /* ---------- guru: satu tokoh, empat pose ---------- */
  var guru = $('#guru'), poseA = $('#pose-a'), poseB = $('#pose-b');
  var POSE = { melambai: 'aset/guru.webp', jempol: 'aset/guru-jempol.webp', semangat: 'aset/guru-semangat.webp', tunjuk: 'aset/guru-tunjuk.webp' };
  var poseKini = 'melambai';
  function pose(nama) {
    if (nama === poseKini) return;
    poseKini = nama;
    var depan = poseA.classList.contains('a') ? poseA : poseB, belakang = depan === poseA ? poseB : poseA;
    belakang.src = POSE[nama];
    belakang.classList.add('a'); depan.classList.remove('a');
  }
  function ukuranGuru(k) {
    guru.className = guru.className.replace(/\bg-\w+\b/g, '').trim() + ' g-' + k;
  }
  function gerak(kelas, ms) {
    if (KURANG) return;
    guru.classList.remove('lompat', 'goyang'); void guru.offsetWidth; guru.classList.add(kelas);
    setTimeout(function () { guru.classList.remove(kelas); }, ms);
  }

  /* ---------- teks mengetik (klik untuk melewati) ---------- */
  var ketikTimer = null;
  function ketik(el, teks, selesai) {
    clearInterval(ketikTimer);
    el.textContent = '';
    if (KURANG) { el.textContent = teks; if (selesai) selesai(); return; }
    var i = 0;
    function henti() { clearInterval(ketikTimer); el.textContent = teks; el.parentNode.removeEventListener('click', henti); if (selesai) selesai(); }
    el.parentNode.addEventListener('click', henti);
    ketikTimer = setInterval(function () {
      i++; el.textContent = teks.slice(0, i);
      if (i >= teks.length) { clearInterval(ketikTimer); el.parentNode.removeEventListener('click', henti); if (selesai) selesai(); }
    }, 35);
  }

  /* ---------- perpindahan layar ---------- */
  var BG = { pembuka: 'bg-pembuka', sapa: 'bg-kelas', cara: 'bg-kelas', soal: 'bg-kelas', refleksi: 'bg-kelas', skor: 'bg-pembuka', peta: 'bg-tangga' };
  var layarKini = 'pembuka', timers = [];
  function tunda(fn, ms) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function bersih() { timers.forEach(clearTimeout); timers = []; clearInterval(ketikTimer); }

  function pindah(nama) {
    bersih();
    $$('.layar').forEach(function (l) { l.classList.remove('on'); });
    $('#scr-' + nama).classList.add('on');
    $$('.bg').forEach(function (b) { b.classList.remove('on'); });
    $('#' + BG[nama]).classList.add('on');
    stage.dataset.scr = nama;
    layarKini = nama;
    volMusik(nama);
    $('#bg-pembuka').style.transform = '';
    tutupUmpan(true);
    $$('.balon').forEach(function (b) { b.classList.remove('on'); });
    if (nama === 'sapa') masukSapa();
    else if (nama === 'cara') masukCara();
    else if (nama === 'peta') masukPeta();
    else if (nama === 'refleksi') masukRefleksi();
    else if (nama === 'skor') masukSkor();
  }

  /* ================= LAYAR 1: PEMBUKA ================= */
  (function bangunJudul() {
    var j = $('#judul');
    var teks = 'MISI TAPIN';
    var warna = [['#ff9a9a', '#e11d48'], ['#ffc46b', '#f97316'], ['#fff07a', '#eab308'], ['#a8f08a', '#16a34a'],
                 ['#8fe3ff', '#0ea5e9'], ['#8fb4ff', '#2563eb'], ['#c4a0ff', '#7c3aed'], ['#ff9fe0', '#db2777'], ['#ffb26b', '#ea580c']];
    var n = 0;
    teks.split('').forEach(function (ch) {
      if (ch === ' ') { var sp = document.createElement('span'); sp.className = 'spasi'; j.appendChild(sp); return; }
      var s = document.createElement('span');
      s.className = 'h'; s.textContent = ch; s.setAttribute('data-c', ch);
      s.style.setProperty('--fs', '152px');
      s.style.setProperty('--c1', warna[n][0]); s.style.setProperty('--c2', warna[n][1]);
      s.style.setProperty('--rot', ((n - 4) * 1.7).toFixed(1) + 'deg');
      s.style.setProperty('--dy', (Math.pow(n - 4, 2) * 1.1).toFixed(1) + 'px');
      s.style.animationDelay = (n * 0.1) + 's, ' + (1.4 + n * 0.12) + 's';
      s.addEventListener('click', function () { suara.pop(); s.classList.remove('lompat'); void s.offsetWidth; s.classList.add('lompat'); });
      j.appendChild(s); n++;
    });
  })();
  // sedikit parallax mengikuti kursor (hanya komputer)
  window.addEventListener('mousemove', function (e) {
    if (layarKini !== 'pembuka' || KURANG) return;
    var dx = (e.clientX / window.innerWidth - 0.5) * -16, dy = (e.clientY / window.innerHeight - 0.5) * -10;
    $('#bg-pembuka').style.transform = 'scale(1.04) translate(' + dx + 'px,' + dy + 'px)';
  });
  $('#btn-mulai').addEventListener('click', function () { suara.klik(); ukuranGuru('sapa'); pose('melambai'); pindah('sapa'); });

  /* ================= LAYAR 2: SAPAAN ================= */
  function masukSapa() {
    ukuranGuru('sapa'); pose('melambai');
    guru.classList.remove('masuk'); void guru.offsetWidth; if (!KURANG) guru.classList.add('masuk');
    var balon = $('#balon-sapa'), teks = $('.teks', balon);
    teks.textContent = '';
    tunda(function () {
      balon.classList.add('on'); suara.pop();
      ketik(teks, 'Halo anak-anak! Ibu guru akan menemani kalian belajar sambil bermain di misi Tangga Pintar.');
    }, 800);
  }
  $('#btn-sapa-lanjut').addEventListener('click', function () { suara.klik(); pindah('cara'); });

  /* ================= LAYAR 3: CARA BERMAIN ================= */
  function titik(n, wr, w2, delay) {
    var d = document.createElement('i');
    d.className = 'titik'; d.style.setProperty('--w', wr); d.style.setProperty('--w2', w2);
    d.style.animationDelay = delay + 's'; return d;
  }
  function masukCara() {
    ukuranGuru('cara'); pose('tunjuk');
    var li = $$('#langkah-cara li'), kk = $$('.kartu-contoh');
    li.forEach(function (x) { x.classList.remove('on'); });
    kk.forEach(function (x) { x.classList.remove('on'); });
    var pa = $('#peraga-a'); pa.innerHTML = '';
    var W = [['#ffb3c1', '#e11d48'], ['#a7f3d0', '#059669']];
    for (var g = 0; g < 2; g++) {
      var grp = document.createElement('div'); grp.className = 'grup';
      for (var k = 0; k < 4; k++) grp.appendChild(titik(0, W[g][0], W[g][1], 0.2 + (g * 4 + k) * 0.05));
      pa.appendChild(grp);
    }
    li.forEach(function (x, i) { tunda(function () { x.classList.add('on'); suara.pop(); }, 700 + i * 700); });
    kk.forEach(function (x, i) { tunda(function () { x.classList.add('on'); suara.pop(); }, 4300 + i * 400); });
  }
  $('#btn-ke-tangga').addEventListener('click', function () { suara.klik(); pindah('peta'); });

  /* ================= LAYAR 4: PETA LEVEL ================= */
  function terbuka(i) { return i === 0 || progres.selesai[i - 1]; }
  var barusSelesai = -1;
  function masukPeta() {
    var bands = $('#bands'), lev = $('#levels');
    bands.innerHTML = ''; lev.innerHTML = '';
    var aktifTelahDitandai = false;
    for (var i = 0; i < 5; i++) {
      var b = BAND[i], band = document.createElement('div');
      band.className = 'band' + (terbuka(i) ? '' : ' kunci');
      band.style.cssText = 'left:' + b.x + 'px;top:' + b.y + 'px;width:' + b.w + 'px;height:' + b.h + 'px';
      band.id = 'band' + i; bands.appendChild(band);

      var grp = document.createElement('div'); grp.className = 'grp-lv';
      grp.style.top = (TENGAH_Y[i] - 48) + 'px';
      var btn = document.createElement('button'); btn.type = 'button';
      var buka = terbuka(i);
      var aktif = buka && !progres.selesai[i] && !aktifTelahDitandai;
      if (aktif) aktifTelahDitandai = true;
      btn.className = 'lv' + (buka ? '' : ' kunci') + (aktif ? ' aktif' : '');
      btn.style.setProperty('--k1', WARNA[i].k1); btn.style.setProperty('--k2', WARNA[i].k2);
      btn.style.animationDelay = ((4 - i) * 0.12) + 's';
      btn.setAttribute('aria-label', 'Level ' + (i + 1) + ' ' + LEVEL[i].nama + (buka ? '' : ', terkunci'));
      if (buka) btn.textContent = String(i + 1);
      else btn.innerHTML = '<svg viewBox="0 0 24 24" width="42" height="42"><path d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5zm-3 8V7a3 3 0 0 1 6 0v3H9z" fill="#fff"/></svg>';
      (function (idx, bukaa) {
        btn.addEventListener('click', function () {
          if (!bukaa) { suara.salah(); btn.animate && btn.animate([{ transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'none' }], 200); return; }
          suara.klik(); mulaiLevel(idx);
        });
      })(i, buka);

      var lbl = document.createElement('div'); lbl.className = 'lbl'; lbl.style.animationDelay = (0.4 + (4 - i) * 0.12) + 's';
      var bs = progres.bintang[i], str = '';
      for (var s = 0; s < 3; s++) str += '<span class="' + (progres.selesai[i] && s < bs ? 'on' : 'off') + '">★</span>';
      lbl.innerHTML = '<div class="nm">' + LEVEL[i].nama + '</div><div class="bs">' + str + '</div>';
      grp.appendChild(btn); grp.appendChild(lbl); lev.appendChild(grp);
    }
    $('#btn-lihat-skor').hidden = !progres.selesai.every(Boolean);
    // anak tangga menyala berurutan dari bawah sampai level yang baru selesai
    if (barusSelesai >= 0) {
      var sampai = barusSelesai; barusSelesai = -1;
      for (var k = 0; k <= sampai; k++) {
        (function (kk) { tunda(function () { var el = $('#band' + kk); if (el) { el.classList.add('nyala'); suara.bintang(kk); } }, 500 + kk * 200); })(k);
      }
    }
  }
  $('#btn-lihat-skor').addEventListener('click', function () { suara.klik(); pindah('skor'); });

  /* ================= LAYAR 5-9: SOAL ================= */
  var gs = null;
  var visualPensil = null;

  function mulaiLevel(n) {
    var L = LEVEL[n];
    gs = { n: n, langkah: 0, salah: 0, masukan: '', selesai: false, fase: 'pahami' };
    $('#pill-lv').textContent = 'Level ' + (n + 1);
    $('#pill-nama').textContent = L.nama;
    var st = $('#soal-teks');
    st.textContent = L.soal; st.className = L.soal.length > 120 ? 'kecil' : '';
    st.style.animation = 'none'; void st.offsetWidth; st.style.animation = '';
    $('#catatan').hidden = true; $('#catatan').innerHTML = '';
    $('#visual').innerHTML = ''; visualPensil = null;
    stage.dataset.fase = 'pilih';
    tampilPilihan('pahami');
    perbaruiTahap();
    gs.masukan = ''; tampilMasukan();
    $$('#kesempatan i').forEach(function (i) { i.classList.remove('hilang'); });
    $('#balon-petunjuk').classList.remove('on');
    ukuranGuru('soal'); pose('tunjuk');
    pindah('soal');
    // pindah() menutup umpan dan balon, jadi pose dan orientasi dipasang ulang setelahnya
    ukuranGuru('soal'); pose('tunjuk');
    tunda(function () { bicaraGuru(L.pbl.orientasi, 11000); }, 700);
  }

  /* --- guru berbicara lewat balon bawah --- */
  function bicaraGuru(teks, lama) {
    var b = $('#balon-petunjuk'), t = $('.teks', b);
    b.classList.add('on'); suara.pop();
    ketik(t, teks);
    clearTimeout(gs && gs.tHint);
    if (gs) gs.tHint = setTimeout(function () { b.classList.remove('on'); }, lama || 9000);
  }

  /* --- tahap Pahami dan Rencanakan: memilih jawaban --- */
  function acak(a) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function tampilPilihan(fase) {
    var L = LEVEL[gs.n], d = L.pbl[fase], v = $('#visual');
    v.innerHTML = '';
    var p = document.createElement('div'); p.className = 'pilih';
    var jdl = document.createElement('div'); jdl.className = 'jdl';
    jdl.innerHTML = '<b>' + (fase === 'pahami' ? 'TAHAP 1 · PAHAMI MASALAH' : 'TAHAP 2 · RENCANAKAN CARANYA') + '</b><span>' + d.tanya + '</span>';
    p.appendChild(jdl);
    var urut = acak(d.opsi.map(function (x, i) { return i; }));
    urut.forEach(function (idx, k) {
      var bt = document.createElement('button'); bt.type = 'button'; bt.className = 'opsi'; bt.textContent = d.opsi[idx];
      bt.style.animationDelay = (k * 0.1) + 's';
      bt.addEventListener('click', function () { pilihOpsi(fase, bt, idx === 0); });
      p.appendChild(bt);
    });
    v.appendChild(p);
  }
  function pilihOpsi(fase, bt, benar) {
    if (!gs || gs.fase !== fase || bt.disabled) return;
    var L = LEVEL[gs.n];
    if (!benar) {
      bt.classList.add('salah'); bt.disabled = true; suara.salah(); pose('semangat');
      bicaraGuru(fase === 'pahami' ? 'Hampir! Baca soalnya sekali lagi dengan teliti ya.' : 'Belum cocok. Coba pikirkan cara yang pas untuk masalah ini.', 5000);
      return;
    }
    bt.classList.add('benar'); suara.langkah(); pose('jempol');
    $$('.opsi', $('#visual')).forEach(function (o) { o.disabled = true; });
    tunda(function () {
      pose('tunjuk');
      if (fase === 'pahami') {
        var c = $('#catatan');
        c.innerHTML = '<span><b>Diketahui:</b> ' + L.pbl.diketahui + '</span><span><b>Ditanya:</b> ' + L.pbl.ditanya + '</span>';
        c.hidden = false;
        gs.fase = 'rencana'; tampilPilihan('rencana'); perbaruiTahap();
      } else {
        gs.fase = 'isi'; stage.dataset.fase = 'isi';
        $('#balon-petunjuk').classList.remove('on');
        bangunVisual(L); renderLangkah();
      }
    }, 850);
  }

  /* --- penunjuk tahap di bagian atas papan tulis --- */
  function perbaruiTahap() {
    var L = LEVEL[gs.n], idx;
    if (gs.fase === 'pahami') idx = 0;
    else if (gs.fase === 'rencana') idx = 1;
    else idx = (L.langkah[gs.langkah] && L.langkah[gs.langkah].tahap === 'periksa') ? 3 : 2;
    if (gs.selesai) idx = 4;
    $$('#tahap i').forEach(function (el, i) {
      el.className = i < idx ? 'selesai' : (i === idx ? 'aktif' : '');
    });
  }

  function bangunVisual(L) {
    var v = $('#visual'); v.innerHTML = ''; visualPensil = null;
    if (L.tipe === 'pensil') bangunPensil(v);
    else if (L.tipe === 'buku') bangunBuku(v);
    else if (L.tipe === 'krayon') bangunKrayon(v);
    else bangunLangkah(v, L);
  }

  /* --- level 1: seret pensil ke wadah --- */
  function bangunPensil(v) {
    var pool = document.createElement('div'); pool.className = 'pool';
    var wd = document.createElement('div'); wd.className = 'wadahs';
    var w1 = buatWadah('Kelompok 1'), w2 = buatWadah('Kelompok 2');
    wd.appendChild(w1); wd.appendChild(w2);
    v.appendChild(pool); v.appendChild(wd);
    visualPensil = { pool: pool, wadah: [w1, w2] };
    for (var i = 0; i < 8; i++) {
      var p = new Image(); p.src = 'aset/pensil.webp'; p.className = 'pensil'; p.alt = 'pensil'; p.draggable = false;
      p.style.animationDelay = (i * 0.07) + 's';
      pasangSeret(p); pool.appendChild(p);
    }
    perbaruiWadah();
    // ketuk wadah memindahkan satu pensil dari kumpulan
    [w1, w2].forEach(function (w) {
      w.addEventListener('click', function (e) {
        if (e.target.classList.contains('pensil')) return;
        var p = $('.pensil', pool); if (p) { w.appendChild(p); suara.pop(); perbaruiWadah(); }
      });
    });
  }
  function buatWadah(nama) {
    var w = document.createElement('div'); w.className = 'wadah';
    var lb = document.createElement('div'); lb.className = 'lb'; lb.textContent = nama; w.appendChild(lb);
    w.setAttribute('data-nama', nama); return w;
  }
  function perbaruiWadah() {
    if (!visualPensil) return;
    visualPensil.wadah.forEach(function (w) {
      var n = $$('.pensil', w).length;
      $('.lb', w).textContent = w.getAttribute('data-nama') + (n ? ' (' + n + ')' : '');
    });
  }
  function pasangSeret(p) {
    p.addEventListener('pointerdown', function (e) {
      if (e.button && e.button !== 0) return;
      e.preventDefault();
      var pr = p.getBoundingClientRect();
      var m = { x: e.clientX, y: e.clientY, dari: p.parentNode, jauh: false, ox: (e.clientX - pr.left) / skala, oy: (e.clientY - pr.top) / skala };
      function dalam(el, ev) { var r = el.getBoundingClientRect(); return ev.clientX > r.left && ev.clientX < r.right && ev.clientY > r.top && ev.clientY < r.bottom; }
      function gerakP(ev) {
        if (!m.jauh && Math.hypot(ev.clientX - m.x, ev.clientY - m.y) > 7) {
          m.jauh = true; $('#board').appendChild(p); p.classList.add('seret');
        }
        if (m.jauh) {
          var br = $('#board').getBoundingClientRect();
          p.style.left = ((ev.clientX - br.left) / skala - m.ox) + 'px';
          p.style.top = ((ev.clientY - br.top) / skala - m.oy) + 'px';
          visualPensil.wadah.forEach(function (w) { w.classList.toggle('sorot', dalam(w, ev)); });
        }
      }
      function lepasP(ev) {
        window.removeEventListener('pointermove', gerakP);
        window.removeEventListener('pointerup', lepasP);
        window.removeEventListener('pointercancel', lepasP);
        visualPensil.wadah.forEach(function (w) { w.classList.remove('sorot'); });
        if (!m.jauh) {
          // ketuk: dari kumpulan ke wadah yang lebih sedikit, dari wadah kembali ke kumpulan
          if (m.dari === visualPensil.pool) {
            var a = visualPensil.wadah;
            (($$('.pensil', a[0]).length <= $$('.pensil', a[1]).length) ? a[0] : a[1]).appendChild(p);
          } else visualPensil.pool.appendChild(p);
          suara.pop(); perbaruiWadah(); return;
        }
        p.classList.remove('seret'); p.style.left = ''; p.style.top = '';
        var tujuan = null;
        visualPensil.wadah.forEach(function (w) { if (dalam(w, ev)) tujuan = w; });
        (tujuan || visualPensil.pool).appendChild(p);
        suara.pop(); perbaruiWadah();
      }
      window.addEventListener('pointermove', gerakP);
      window.addEventListener('pointerup', lepasP);
      window.addEventListener('pointercancel', lepasP);
    });
  }

  /* --- level 2: buku, tombol Ambil 5 --- */
  function bangunBuku(v) {
    var atas = document.createElement('div'); atas.className = 'v2-atas';
    var rak = document.createElement('div'); rak.className = 'rakbuku';
    for (var i = 0; i < 20; i++) {
      var b = new Image(); b.src = 'aset/buku.webp'; b.className = 'buku'; b.alt = 'buku'; b.style.animation = 'pop .5s ' + (i * 0.03) + 's cubic-bezier(.3,1.7,.5,1) backwards';
      rak.appendChild(b);
    }
    var panel = document.createElement('div'); panel.className = 'panel-ambil';
    panel.innerHTML = '<button type="button" class="tombol kuning" id="btn-ambil">Ambil 5</button><div id="hitung">Diambil: <b id="jml">0</b> kali</div>';
    atas.appendChild(rak); atas.appendChild(panel);
    var raks = document.createElement('div'); raks.className = 'raks'; raks.id = 'raks';
    v.appendChild(atas); v.appendChild(raks);
    var diambil = 0;
    $('#btn-ambil').addEventListener('click', function () {
      var sisa = $$('.buku:not(.ambil)', rak);
      if (!sisa.length) return;
      sisa.slice(0, 5).forEach(function (b) { b.classList.add('ambil'); });
      diambil++; $('#jml').textContent = diambil; suara.pop();
      var r = document.createElement('div'); r.className = 'rak';
      r.innerHTML = '<span class="nr">Rak ' + diambil + '</span>';
      for (var k = 0; k < 5; k++) { var im = new Image(); im.src = 'aset/buku.webp'; im.alt = ''; r.appendChild(im); }
      raks.appendChild(r);
      if (sisa.length <= 5) { this.disabled = true; }
    });
  }

  /* --- level 3: krayon dan enam kotak --- */
  function bangunKrayon(v) {
    var d = document.createElement('div'); d.className = 'v3';
    var kiri = '<div class="kiri"><img src="aset/krayon.webp" alt="krayon"><div class="bil">42</div><small>krayon</small></div>';
    var kotak = '<div class="kotaks">';
    for (var i = 1; i <= 6; i++) kotak += '<div class="kotak">' + i + '</div>';
    kotak += '</div>';
    d.innerHTML = kiri + '<div style="font-size:54px;font-weight:700;color:#dc2626">:</div>' + kotak;
    v.appendChild(d);
    var k = document.createElement('div'); k.className = 'kalimat'; k.id = 'kalimat'; k.innerHTML = '6 × ... = 42'; v.appendChild(k);
  }

  /* --- level 4 dan 5: langkah bertahap --- */
  function bangunLangkah(v, L) {
    var d = document.createElement('div'); d.className = 'v4';
    d.innerHTML = '<img src="aset/' + L.tipe + '.webp" alt="' + L.tipe + '">';
    var rows = document.createElement('div'); rows.className = 'rows'; rows.id = 'rows';
    L.langkah.forEach(function (l, i) {
      var r = document.createElement('div'); r.className = 'baris-hitung'; r.id = 'baris' + i; rows.appendChild(r);
    });
    d.appendChild(rows); v.appendChild(d);
  }

  function isiBaris(i, status) {
    var L = LEVEL[gs.n], l = L.langkah[i], el = $('#baris' + i);
    if (!el) return;
    var A = status === 'selesai' ? '<span class="jwb">' + l.jawab + '</span>' : '<span class="tanda">?</span>';
    el.innerHTML = l.baris.replace('{A}', A);
    el.className = 'baris-hitung tampil ' + status;
  }

  function renderLangkah() {
    var L = LEVEL[gs.n], l = L.langkah[gs.langkah];
    $('#kt-label').innerHTML = (L.langkah.length > 1 ? 'Langkah ' + (gs.langkah + 1) + ' dari ' + L.langkah.length + ': ' : 'Jawabanmu: ') + l.label;
    $('#kt-satuan').textContent = l.satuan;
    gs.masukan = ''; tampilMasukan();
    if (L.langkah[0].baris) {
      for (var i = 0; i < L.langkah.length; i++) {
        if (i < gs.langkah) isiBaris(i, 'selesai');
        else if (i === gs.langkah) isiBaris(i, 'aktif');
        else { var el = $('#baris' + i); if (el) el.className = 'baris-hitung'; }
      }
    }
    perbaruiTahap();
  }
  function tampilMasukan() { $('#masukan').textContent = gs ? gs.masukan : ''; }

  /* --- papan angka dan keyboard --- */
  function ketikAngka(k) {
    if (!gs || gs.selesai || gs.fase !== 'isi' || layarKini !== 'soal' || $('#scr-umpan').classList.contains('on')) return;
    if (k === 'del') gs.masukan = gs.masukan.slice(0, -1);
    else if (k === 'ok') { periksa(); return; }
    else if (gs.masukan.length < 3) gs.masukan += k;
    suara.pop(); tampilMasukan();
  }
  $$('#kunci button').forEach(function (b) { b.addEventListener('click', function () { ketikAngka(b.getAttribute('data-k')); }); });
  document.addEventListener('keydown', function (e) {
    if (layarKini !== 'soal') return;
    if (/^[0-9]$/.test(e.key)) ketikAngka(e.key);
    else if (e.key === 'Backspace') ketikAngka('del');
    else if (e.key === 'Enter') { e.preventDefault(); if ($('#scr-umpan').classList.contains('on')) $('#btn-umpan').click(); else periksa(); }
  });

  /* --- petunjuk --- */
  $('#btn-petunjuk').addEventListener('click', function () {
    if (!gs) return;
    suara.klik(); pose('tunjuk');
    var L = LEVEL[gs.n];
    bicaraGuru(gs.fase === 'pahami' ? 'Baca soal pelan-pelan, lalu cari kalimat yang diawali kata Tentukan.' : L.petunjuk, 9000);
  });

  /* --- memeriksa jawaban --- */
  $('#btn-periksa').addEventListener('click', function () { periksa(); });
  function periksa() {
    if (!gs || gs.selesai || gs.fase !== 'isi') return;
    if (gs.masukan === '') {
      var k = $('#kartu'); k.classList.remove('guncang'); void k.offsetWidth; k.classList.add('guncang'); suara.salah(); return;
    }
    var L = LEVEL[gs.n], l = L.langkah[gs.langkah];
    if (parseInt(gs.masukan, 10) === l.jawab) {
      if (gs.langkah < L.langkah.length - 1) {
        // langkah benar, lanjut ke langkah berikutnya
        if (l.baris) isiBaris(gs.langkah, 'selesai');
        gs.langkah++; suara.langkah(); renderLangkah();
        var kk = $('#kartu'); kk.animate && kk.animate([{ transform: 'scale(1.03)' }, { transform: 'none' }], 250);
      } else {
        if (l.baris) isiBaris(gs.langkah, 'selesai');
        gs.selesai = true; perbaruiTahap();
        var bintang = 3 - gs.salah;
        progres.selesai[gs.n] = true; progres.bintang[gs.n] = Math.max(progres.bintang[gs.n] || 0, bintang); simpan();
        tunda(function () { umpan('benar', bintang); }, 500);
      }
    } else {
      gs.salah++;
      $$('#kesempatan i').forEach(function (el, i) { el.classList.toggle('hilang', i >= 3 - gs.salah); });
      var kt = $('#kartu'); kt.classList.remove('guncang'); void kt.offsetWidth; kt.classList.add('guncang');
      suara.salah();
      if (gs.n === 2) $('#kalimat').classList.add('on');
      if (gs.salah >= 3) {
        gs.selesai = true;
        progres.selesai[gs.n] = true; simpan();
        tunda(function () { umpan('habis', 0); }, 450);
      } else tunda(function () { umpan('salah', 3 - gs.salah); }, 350);
      gs.masukan = ''; tampilMasukan();
    }
  }

  /* ================= LAYAR 10: UMPAN BALIK ================= */
  function tutupUmpan(cepat) {
    stage.dataset.umpan = '0'; if (layarKini === 'soal') volMusik('soal');
    $('#scr-umpan').classList.remove('on'); $('#dim').classList.remove('on');
    $('#balon-umpan').classList.remove('on'); $('#papan-umpan').classList.remove('on');
    if (!cepat && layarKini === 'soal') ukuranGuru('soal');
  }
  var umpanJenis = '';
  function umpan(jenis, info) {
    umpanJenis = jenis;
    var L = LEVEL[gs.n], bal = $('#balon-umpan'), pap = $('#papan-umpan');
    var bt = $('#bintang-umpan'), tu = $('#teks-umpan'), btn = $('#btn-umpan');
    $('#balon-petunjuk').classList.remove('on');
    stage.dataset.umpan = '1'; volMusik('umpan');
    $('#scr-umpan').classList.add('on'); $('#dim').classList.add('on');
    ukuranGuru('umpan');
    bal.classList.remove('on'); pap.classList.remove('on', 'guncang');
    var tb = $('.teks', bal);
    bt.innerHTML = '';
    if (jenis === 'benar') {
      pose('jempol'); tb.textContent = 'Hebat!';
      for (var i = 0; i < 3; i++) {
        var s = document.createElement('span'); s.textContent = '★';
        if (i < info) { s.className = 'on'; s.style.animationDelay = (0.6 + i * 0.35) + 's'; }
        bt.appendChild(s);
      }
      tu.innerHTML = L.bahas;
      btn.textContent = 'Lanjut ▸';
      suara.benar(); konfeti(150); gerak('lompat', 750);
      for (var j = 0; j < info; j++) (function (jj) { tunda(function () { suara.bintang(jj); }, 700 + jj * 350); })(j);
    } else if (jenis === 'salah') {
      pose('semangat'); tb.textContent = 'Belum tepat, ayo coba lagi!';
      bt.innerHTML = '';
      tu.innerHTML = '<b>Petunjuk:</b> ' + L.petunjuk + '<br><small>Kesempatan tersisa: ' + info + '</small>';
      btn.textContent = 'Coba lagi ▸';
      gerak('goyang', 2400);
      tunda(function () { pap.classList.add('guncang'); }, 450);
    } else {
      pose('semangat'); tb.textContent = 'Tidak apa-apa, ayo kita bahas bersama!';
      for (var q = 0; q < 3; q++) { var s2 = document.createElement('span'); s2.textContent = '★'; bt.appendChild(s2); }
      tu.innerHTML = '<b>Pembahasan:</b> ' + L.bahas;
      btn.textContent = 'Lanjut ▸';
      gerak('goyang', 2400);
    }
    tunda(function () { bal.classList.add('on'); pap.classList.add('on'); }, 250);
  }
  $('#btn-umpan').addEventListener('click', function () {
    suara.klik();
    if (umpanJenis === 'salah') {
      tutupUmpan(); pose('tunjuk'); ukuranGuru('soal'); return;
    }
    // benar atau habis: lanjut
    var n = gs.n;
    if (n === 4) { pindah('refleksi'); }
    else { barusSelesai = n; pindah('peta'); }
  });

  /* ================= REFLEKSI (fase analisis dan evaluasi proses) ================= */
  function masukRefleksi() {
    ukuranGuru('cara'); pose('tunjuk');
    var pr = $('#pilih-ref'); pr.innerHTML = '';
    var btn = $('#btn-ref-lanjut'); btn.disabled = !progres.refleksi;
    REFLEKSI.forEach(function (t, i) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'ref' + (progres.refleksi === t ? ' pilih' : '');
      b.textContent = t; b.style.animationDelay = (0.5 + i * 0.12) + 's';
      b.addEventListener('click', function () {
        $$('.ref', pr).forEach(function (x) { x.classList.remove('pilih'); });
        b.classList.add('pilih'); progres.refleksi = t; simpan(); btn.disabled = false; suara.langkah(); pose('jempol');
      });
      pr.appendChild(b);
    });
  }
  $('#btn-ref-lanjut').addEventListener('click', function () { if (this.disabled) return; suara.klik(); pindah('skor'); });

  /* ================= LAYAR 11: SKOR AKHIR ================= */
  function masukSkor() {
    var total = progres.bintang.reduce(function (a, b) { return a + b; }, 0);
    var skor = Math.round(total / 15 * 100);
    var bagus = skor >= 60;
    ukuranGuru('skor'); pose(bagus ? 'jempol' : 'semangat');
    $('#skor').textContent = '0';
    var bs = $('#bintang-skor'); bs.innerHTML = '';
    for (var g = 0; g < 5; g++) {
      var grp = document.createElement('div'); grp.className = 'grp';
      for (var s = 0; s < 3; s++) { var x = document.createElement('span'); x.className = 'bt'; x.textContent = '★'; grp.appendChild(x); }
      bs.appendChild(grp);
    }
    $('#ket-skor').textContent = 'Total bintang: ' + total + ' dari 15' + (progres.refleksi ? '. Strategi favoritmu: ' + progres.refleksi.toLowerCase() + '.' : '');
    var tb = $('#balon-skor .teks');
    var teks = bagus ? 'Hebat sekali! Kamu sudah naik sampai puncak Tangga Pintar!' : 'Ayo ulangi supaya bintangmu bertambah!';
    tunda(function () { $('#balon-skor').classList.add('on'); suara.pop(); ketik(tb, teks); }, 500);
    // skor naik berhitung
    var t0 = performance.now(), dur = KURANG ? 10 : 1300;
    (function hit(t) {
      var p = Math.min(1, (t - t0) / dur);
      $('#skor').textContent = String(Math.round(skor * p));
      if (p < 1 && layarKini === 'skor') requestAnimationFrame(hit);
    })(t0);
    // bintang muncul satu per satu
    var semua = $$('#bintang-skor .bt'), ke = 0;
    progres.bintang.forEach(function (n, lv) {
      for (var i = 0; i < 3; i++) {
        if (i < n) {
          (function (el, urut) {
            tunda(function () { el.classList.add('on'); suara.bintang(urut % 8); }, 700 + urut * 160);
          })(semua[lv * 3 + i], ke++);
        }
      }
    });
    if (bagus) tunda(function () { konfeti(170); gerak('lompat', 750); }, 600);
  }
  $('#btn-ulangi').addEventListener('click', function () {
    suara.klik(); progres = { selesai: [false, false, false, false, false], bintang: [0, 0, 0, 0, 0], refleksi: '' }; simpan(); pindah('peta');
  });
  $('#btn-kembali').addEventListener('click', function () { suara.klik(); pindah('peta'); });
  $('#btn-awal').addEventListener('click', function () { suara.klik(); pindah('pembuka'); });

  // untuk pengujian dan debug: window.TAPIN
  window.TAPIN = { musik: function () { return { jalan: musik.jalan, langkah: musik.langkah, mati: musik.mati, vol: musik.gain ? musik.gain.gain.value : -1 }; }, pindah: pindah, mulaiLevel: mulaiLevel, progres: function () { return progres; }, reset: function () { progres = muat(); } };
})();
